import 'package:flutter/material.dart';

void main() {
  runApp(const DailyActivitiesApp());
}

class DailyActivitiesApp extends StatelessWidget {
  const DailyActivitiesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Daily Activities Recorder',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: const ActivityHome(),
    );
  }
}

class ActivityHome extends StatefulWidget {
  const ActivityHome({super.key});

  @override
  State<ActivityHome> createState() => _ActivityHomeState();
}

class _ActivityHomeState extends State<ActivityHome> {
  // Lists to store data 
  final List<Map<String, String>> _activities = [];

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _categoryController = TextEditingController();

  void _addActivity() {
   
    if (_nameController.text.isNotEmpty && _categoryController.text.isNotEmpty) {
      setState(() {
        _activities.add({
          'name': _nameController.text,
          'category': _categoryController.text,
        });
      });
      // Clear the inputs after adding 
      _nameController.clear();
      _categoryController.clear();
    }
  }

  void _deleteActivity(int index) {
    setState(() {
      _activities.removeAt(index); // Remove functionality 
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daily Activities Recorder'), // 
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Input field for Activity Name 
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Activity name...',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            // Input field for Time/Category 
            TextField(
              controller: _categoryController,
              decoration: const InputDecoration(
                labelText: 'Time / Category...',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 15),
            // Add Activity Button 
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _addActivity,
                child: const Text('ADD ACTIVITY'),
              ),
            ),
            const Divider(height: 30),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'ACTIVITIES',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
            ),
            const SizedBox(height: 10),
            // Displaying data in a list 
            Expanded(
              child: ListView.builder(
                itemCount: _activities.length,
                itemBuilder: (context, index) {
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    child: ListTile(
                      title: Text(_activities[index]['name']!),
                      subtitle: Text(_activities[index]['category']!),
                      trailing: TextButton(
                        onPressed: () => _deleteActivity(index),
                        child: const Text('Delete', style: TextStyle(color: Colors.red)), // Delete button
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}